package com.blackcyber.lutcamera;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.os.Bundle;
import android.view.TextureView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity implements TextureView.SurfaceTextureListener {

    private static final int PERMISSION_CODE = 100;
    
    private TextureView cameraPreview;
    private Button recordButton;
    private ImageButton cameraSwitchBtn;
    private SeekBar intensitySlider;
    private TextView statusText;
    
    private boolean isRecording = false;
    private boolean useFrontCamera = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeUI();
        checkPermissions();
    }

    private void initializeUI() {
        cameraPreview = findViewById(R.id.cameraPreview);
        recordButton = findViewById(R.id.recordButton);
        cameraSwitchBtn = findViewById(R.id.cameraSwitchButton);
        intensitySlider = findViewById(R.id.intensitySlider);
        statusText = findViewById(R.id.statusText);

        cameraPreview.setSurfaceTextureListener(this);

        recordButton.setOnClickListener(v -> toggleRecording());
        cameraSwitchBtn.setOnClickListener(v -> switchCamera());
        
        intensitySlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                statusText.setText("Intensity: " + progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void checkPermissions() {
        String[] permissions = {
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        };

        boolean allGranted = true;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) 
                    != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }

        if (!allGranted) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_CODE);
        } else {
            statusText.setText("Ready");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                statusText.setText("Ready");
            } else {
                Toast.makeText(this, "Permissions required", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void toggleRecording() {
        isRecording = !isRecording;
        if (isRecording) {
            statusText.setText("Recording...");
            recordButton.setText("Stop");
            recordButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
        } else {
            statusText.setText("Ready");
            recordButton.setText("Record");
            recordButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));
            Toast.makeText(this, "Video saved", Toast.LENGTH_SHORT).show();
        }
    }

    private void switchCamera() {
        useFrontCamera = !useFrontCamera;
        String type = useFrontCamera ? "Front Camera" : "Back Camera";
        statusText.setText(type);
        Toast.makeText(this, type, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {}

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {}

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return true; }

    @Override
    public void onSurfaceTextureFrameAvailable(SurfaceTexture surface) {}
}