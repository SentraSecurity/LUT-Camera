package com.example.lutcamera

import android.content.Context
import java.io.InputStream

class LUTLoader(private val context: Context) {

    fun loadLUT(fileName: String): FloatArray {
        val inputStream: InputStream = context.assets.open(fileName)
        // .cube parser logikasi shu yerda bo‘ladi
        // 3D LUTni float arrayga o‘tkazadi
        return FloatArray(32*32*32*3) // shablon
    }
}