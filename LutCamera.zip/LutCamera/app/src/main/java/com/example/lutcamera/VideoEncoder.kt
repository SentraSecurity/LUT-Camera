package com.example.lutcamera

class VideoEncoder {
    // MediaCodec yordamida 60 FPS video yozish logikasi
    fun startRecording() {}
    fun stopRecording() {}
}